namespace Pantallas_Sistema_facturaci�n
{
    public class Categoria
    {
        public int IdCategoria { get; set; }
        public string NombreCategoria { get; set; }

        public override string ToString() => NombreCategoria;
    }
}

